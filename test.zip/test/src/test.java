public class test {
    static void getNthBinaryNumberWithOnes(int n, int k)
    {
        System.out.println(
                ((n & (1 << (k - 1))) >> (k - 1)));
    }

    // Driver Code
    public static void main(String[] args)
    {
        long n = 5, k = 2;

        // Function Call
        printKthBit(n, k);
    }
}

